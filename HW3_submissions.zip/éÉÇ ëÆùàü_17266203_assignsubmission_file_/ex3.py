import random

ids = ['314771692']


# implementation of a random agent
class Agent:
    def __init__(self, initial_state, zone_of_control, order):
        self.zoc = zone_of_control
        print(initial_state)

    def act(self, state):
        action = []
        healthy = set()
        sick = set()
        for (i, j) in self.zoc:
            if 'H' in state[i][j]:
                healthy.add((i, j))
            if 'S' in state[i][j]:
                sick.add((i, j))
        try:
            to_quarantine = random.sample(sick, 2)
        except ValueError:
            to_quarantine = []
        try:
            to_vaccinate = random.sample(healthy, 1)
        except ValueError:
            to_vaccinate = []
        for item in to_quarantine:
            action.append(('quarantine', item))
        for item in to_vaccinate:
            action.append(('vaccinate', item))

        print("ACTION: ", action)

        return action
